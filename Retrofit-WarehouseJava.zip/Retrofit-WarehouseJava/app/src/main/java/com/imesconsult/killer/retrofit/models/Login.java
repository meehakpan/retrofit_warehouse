package com.imesconsult.killer.retrofit.models;

public class Login {
}
