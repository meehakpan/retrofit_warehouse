package com.imesconsult.killer.retrofit.models;

public class User {
    public String id;
    public String email;
}
