package com.imesconsult.killer.retrofit.models;

public class AuthModel {
    String email;
    String password;

    public AuthModel(String email, String password) {
        this.email = email;
        this.password = password;
    }
}
