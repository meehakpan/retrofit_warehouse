package com.imesconsult.killer.retrofit;

import com.imesconsult.killer.retrofit.models.Item;
import com.imesconsult.killer.retrofit.models.Login;
import com.imesconsult.killer.retrofit.models.AuthModel;

import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.DELETE;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {

    @POST("/api/auth/login")
    Call<HashMap<String, String>> loginToWarehouse(@Body AuthModel auth);


    @POST("/api/auth/signup")
    Call<HashMap<String, String>> createNewAccount(@Body AuthModel auth);

    @POST("/api/items")
    Call<HashMap<String, String>> postNewItem(@Body Item item);

    @PUT("/api/items")
    Call<HashMap<String, String>> putItem(@Body Item item);

    @DELETE("/api/items")
    Call<HashMap<String, String>> deleteItem(@Body Item item);


    @GET("/api/items")
    Call<List<Item>> getAllItems();

}
